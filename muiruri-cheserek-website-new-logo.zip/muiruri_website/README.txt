MUIRURI, CHESEREK & CO. ADVOCATES WEBSITE

To preview locally:
1. Extract this ZIP folder.
2. Open index.html in a modern web browser (Chrome, Edge, Firefox).

To publish online, upload all files and the assets folder to your web hosting provider. Keep the folder structure intact.

Files:
- index.html: website content
- style.css: responsive styling
- script.js: mobile navigation and footer year
- assets/: logo crop and office photo

Contact details currently included:
+254 727 779 370
+254 788 868 268
muiruricheserekadvocates@gmail.com
Equity Plaza, Suite 212, Thika, Kenya
